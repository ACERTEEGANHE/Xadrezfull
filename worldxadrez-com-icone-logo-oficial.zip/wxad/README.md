# WorldXadrez — versão web e preparação para Android

O projeto mantém a versão web e prepara a interface para ser empacotada como aplicativo Android com Capacitor.

## O que funciona sem internet

- Partida local no mesmo dispositivo.
- Partida contra o Robô IA (Amador, Intermediário e Profissional).
- Tabuleiro 3D, movimentos, histórico e controles, pois os arquivos da interface são incluídos no aplicativo.

## O que precisa de internet

As partidas online, salas com código e chat entre dispositivos precisam de um servidor multiplayer publicado e acessível por HTTPS. Defina `VITE_GAME_SERVER_URL` no ambiente de build da pasta `client` (veja `client/.env.example`). A URL de exemplo é um marcador, não um servidor real.

## Testar a versão web

Na raiz do projeto:

```bash
npm install
npm run build
npm run dev
```

## Gerar o projeto Android / APK

Requisitos: Node.js 20+, Android Studio e Android SDK instalados.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, aguarde a sincronização do Gradle. Para gerar um APK de teste, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Para atualizar o app depois de alterar o código web:

```bash
npm run build
npx cap sync android
```

O ZIP contém a configuração e os scripts necessários, mas não inclui um APK já compilado. A compilação final precisa do Android SDK/Gradle.

## Ícone do aplicativo

A versão web/PWA já inclui `manifest.webmanifest`, ícones 192×192 e 512×512, ícone maskable e ícone para iOS. Para gerar os recursos nativos do Android usando a arte em `assets/`, execute na raiz do projeto:

```bash
npm install
npx cap add android   # somente se a pasta android ainda não existir
npm run android:icons
npm run android:sync
```

Depois abra o projeto no Android Studio e gere um novo APK/AAB. O ícone do aplicativo instalado só muda quando o APK/AAB é reconstruído e instalado/publicado novamente.
